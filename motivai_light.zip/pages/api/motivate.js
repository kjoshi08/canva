
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { name, goal, mood } = req.body;
  const prompt = `Generate a personalized motivational response for someone named ${name} whose goal is "${goal}" and who currently feels "${mood}". Include: 1 motivational quote, 1 Instagram caption (max 150 characters), and 1 journal prompt.`;

  try {
    const completion = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': \`Bearer \${process.env.OPENAI_API_KEY}\`
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.8
      })
    });

    const data = await completion.json();
    const content = data.choices[0].message.content;
    const [quoteLine, captionLine, promptLine] = content.split('\n').map(s => s.replace(/^[-\d.]+\s*/, '').trim());

    res.status(200).json({
      quote: quoteLine || 'Stay focused and keep going.',
      caption: captionLine || 'Your future self is watching.',
      prompt: promptLine || 'What can you do today to move 1% closer to your goal?'
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate motivation' });
  }
}
