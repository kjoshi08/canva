# MotivAI
A simple AI-powered motivation generator built with Next.js.
