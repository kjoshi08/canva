# MotivAI
A personalized motivation generator using Next.js and OpenAI API.
