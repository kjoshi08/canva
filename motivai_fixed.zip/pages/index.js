import { useState } from 'react';

export default function Home() {
  const [name, setName] = useState('');
  const [goal, setGoal] = useState('');
  const [mood, setMood] = useState('');
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);

  const generateMotivation = async () => {
    setLoading(true);
    const res = await fetch('/api/motivate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, goal, mood })
    });
    const data = await res.json();
    setResponse(data);
    setLoading(false);
  };

  return (
    <div className="max-w-xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">🧠 MotivAI</h1>
      <p className="mb-4">Enter your name, goal, and mood to get your personalized motivational boost.</p>
      <input type="text" placeholder="Your name" className="w-full p-2 mb-3 border rounded" value={name} onChange={(e) => setName(e.target.value)} />
      <input type="text" placeholder="Your goal" className="w-full p-2 mb-3 border rounded" value={goal} onChange={(e) => setGoal(e.target.value)} />
      <input type="text" placeholder="Your mood" className="w-full p-2 mb-4 border rounded" value={mood} onChange={(e) => setMood(e.target.value)} />
      <button onClick={generateMotivation} disabled={loading} className="px-4 py-2 bg-blue-600 text-white rounded">
        {loading ? 'Generating...' : 'Get Motivation'}
      </button>
      {response && (
        <div className="mt-6 p-4 border rounded shadow">
          <h2 className="text-xl font-semibold mb-2">✨ Your Motivation:</h2>
          <p><strong>Quote:</strong> {response.quote}</p>
          <p><strong>Caption:</strong> {response.caption}</p>
          <p><strong>Journal Prompt:</strong> {response.prompt}</p>
        </div>
      )}
    </div>
  );
}
